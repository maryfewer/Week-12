var a = 100;
var b = 100;
var x = Math.floor(Math.random() * 800);
var y = Math.floor(Math.random() * 600);
var v = Math.floor(Math.random() * 800);
var w = Math.floor(Math.random() * 600);
var t = Math.floor(Math.random() * 800);
var u = Math.floor(Math.random() * 600);
var value = 0
var value2 = 0 


function setup()
    {
        createCanvas(800,600);
    }

    function draw()
    {
        background(0);
        myCharacter();
        winText();
        myObjects();
        moveObjects();
        createExit();
        youWin();
        
    }
    
    function myCharacter()
    {
      fill(value2);
      circle(a,b,100);
    }

    function mouseClicked()
    {
      value2 = 255
    }

    function keyPressed()
    {
      if (key == 'd') 
      {
        a+=15;
      } 
      else if (key == 'a') 
      {
        a-=15;
      }
      else if (key == 's') 
      {
        b+=15;
      }
      else if (key == 'w') 
      {
        b-=15;
      }
    }
    function moveObjects()
    //move Green
    {
      if (x < 800){
        x+=1;
      }
      else {
        x=0;
        y = Math.floor(Math.random()*600);
      }
      // move blue
      if (v < 800){
        v+=2;
      }
      else {
        v=0;
        w = Math.floor(Math.random()*600);
      }
      // move red
      if (u < 600){
        u+=3;
      }
      else {
        u=0;
        t = Math.floor(Math.random()*800);
      }

    }
    function myObjects()
    {
      // Green Shape
      fill(24,200,29);
      circle(x,y,25);
      // Blue Shape
      fill(30,30,255)
      circle(v,w,100);
      //Red
      fill(255,0,29);
      circle(t,u,40);
      
    }

    function createExit()
    {
      fill(102,205,170)
      rect(755,400,50,200);
    }

    function winText()
    {
      fill(value);
      text('you win!', 400,300);
    }

    function youWin()
    {
      if(a > 755 && b > 400)
      {
        value = 255
      }
    }
    